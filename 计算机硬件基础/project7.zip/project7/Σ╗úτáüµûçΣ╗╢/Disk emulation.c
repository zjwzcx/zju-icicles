#include <iostream>
#include <stdio.h>

//#include "zpcfsys.h"
typedef	unsigned char	byte;
typedef	unsigned short	zjie;
typedef	unsigned short	zchr;
typedef	unsigned int	word;

#define SectorBytes	512
#define Sector 		1024
#define DirSector	248
#define DatSector	278


FILE*	vdiskfp;

/**************************************************
 * ��һ�����������ݣ���ת���ɴ�ͷzjie�ṹ��
 * buf: ���ݻ����� 
 * adr: Ҫ���������ţ��Ӵ��̿�ʼ 
 **************************************************/
void readOneClstr(byte* buf, int adr){
	fseek(vdiskfp, adr*SectorBytes, SEEK_SET);
	fread(buf, 1, SectorBytes, vdiskfp);
}
/**************************************************
 * дһ�����������ݣ���ת���ɴ�ͷzjie�ṹ��
 * buf: ���ݻ����� 
 * adr: Ҫд�������ţ��Ӵ��̿�ʼ 
 **************************************************/
int writeOneClstr(byte* buf, int adr){
	fseek(vdiskfp, adr*SectorBytes, SEEK_SET);
	return fwrite(buf, 1, SectorBytes, vdiskfp);
}

int main(int argc, char** argv)
{
	int	i, j, k, size, dirsct = 248;
	zjie	first;
	byte	buf[SectorBytes];
	byte	fnam[30]="string.jv", nam[30]="STRING   JV ";	
	
	if((vdiskfp=fopen("C:\\fat.vhd", "rb+"))==NULL)return -1;
	
	readOneClstr(buf, 248);
	for(i=0; i<SectorBytes; i++){
		if((i&15)==0)printf("\n");
		printf("%02X ",buf[i]);
	}
	printf("\n");
	for(j=0; j<SectorBytes/32; j++){
		for(i=0;i<11; i++){
			if(buf[j*32+i]!=nam[i])break;
		}
		if(i==11)break;
	}
	if(j==SectorBytes/32){
		printf("No file.");
		return 0;
	}
	
	first = buf[j*32+26]+buf[j*32+27]*256;
	size  =   buf[j*32+28]
			+(buf[j*32+29]<<8)
			+(buf[j*32+30]<<16)
			+(buf[j*32+31]<<24);
	printf("first= %d, size= %d\n", first, size);
	for(i=0; i<32; i++){
		printf("%02X ",buf[j*32+i]);
	}
	printf("\n=========================\n\n");
	
	readOneClstr(buf, DatSector+first);
	for(i=0; i<Sector; i++){
		printf("%c",buf[i]);
	}

		
}

